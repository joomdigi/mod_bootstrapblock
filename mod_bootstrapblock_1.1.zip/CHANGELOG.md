### 1.0 / 11-02-2013###

* Initial project folder structure
* Created README.md and CHANGELOG.md files
* XML manifest file
* Display view file
* Helper class

### 1.1 / 12-12-2013###

Added glyphicon support


### 1.2 / 11-17-2014###

* Fixed Extra div bug